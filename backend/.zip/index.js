const express = require("express");
const cors = require("cors");
const {dbConnection} =require('./DB/config')
const mongoose = require("mongoose");
const bodyParser= require('body-parser')
const User     = require('./models/Usuarios');
const path = require('path');
const fileUpload =require('express-fileupload');

// const port = 4000;
const app = express();
require('dotenv').config();

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));
app.use(express.json());

//DB Conection carpeta DB
dbConnection();

app.use(cors());

////////Autenticacion /////////
/////login,create,renew
app.use('/api/auth',require('./routes/auth'));

////////////CRUD FORMS/////////////////

////////////Create 
app.use('/api/forms',require('./routes/forms'));
////////////Read
app.use('/api/info',require('./routes/info'));
////////////Update
app.use('/api/update',require('./routes/update'));

/////////////// en prueba ///////////////////////////
////////////Delete
app.use('/api/borrar',require('./routes/borrarOne'));
//////////////////////////////////////////////////////

////////////   Evidencias  en prueba /////////////////////
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use('/api/upload',require('./routes/upload'));



app.listen(process.env.PORT, () => {
    // console.log(`at http://localhost:${port}`)
    console.log(`at http://localhost:${process.env.PORT}`);
  })