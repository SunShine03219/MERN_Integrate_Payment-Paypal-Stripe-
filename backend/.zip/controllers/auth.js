const express = require('express');
const bcrypt = require('bcryptjs');
const {validationResult} = require('express-validator');
const Usuarios = require('../models/Usuarios');

const CrearUsuario = async(req,res= express.response)=>{
    // console.log(req.body)
    const {email,pwd} = req.body;

    try{
    
    let usuario = await Usuarios.findOne({email})
    console.log(usuario);
    console.log(pwd)

        if(usuario){
            return res.status(400).json({
                ok:false,
                uid:usuario.id,
                msg:'este correo ya existe'
            })
        }
    usuario = new Usuarios(req.body);

    ///encriptando password
    const salt  = bcrypt.genSaltSync(10);//10 por defecto
    // usuario.pwd = bcrypt.hashSync(pwd , salt);

    await usuario.save();

    res.status(201).json({
        ok:true,
        msg:'register',
        pass: pwd
        // name,      
        // email,
        // pwd
    })
    }catch (error){
        console.log(error);
        res.status(500).json({
            ok:false,
            msg:'por favor notifica al admin Aldo Sanchez Leon',
        })
    }
}


const LoginUsuario  = async(req,res = express.response)=>{
    const {email,pwd} = req.body;
    res.status(201).json({
        ok:true,
        msg:'login',      
        email,
        pwd
    })

}

const RevalidarUsuario  = async(req,res= express.response)=>{
    const {email,pwd} = req.body;
    res.json({
        ok:true,
        msg:'renew',
        email,
        pwd
    })
}

const UpdateUsuario  = async(req,res= express.response)=>{
    const {id,puesto} = req.body;
    try{
    
    let usuarioUpdate = await Usuarios.updateOne({_id:"621d1866682be653270fe7e4"},{puesto:"TA"})
    console.log(usuarioUpdate);
    // await usuarioUpdate.save();
    res.status(201).json({
        ok:true,
        msg:'update',
    })
    }catch (error){
        console.log(error);
        res.status(500).json({
            ok:false,
            msg:'por favor notifica al admin Aldo Sanchez Leon',
        })
    }
}


module.exports ={
    CrearUsuario,RevalidarUsuario,LoginUsuario,UpdateUsuario
}