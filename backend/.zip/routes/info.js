// Rutas de forms
// host + /api/info
const {check} = require('express-validator') 
const { Router } = require('express');
const { readProduccion,//priduccion
        getAllProducts,//produccio
        getAllForms,//calidad
        readPruebas,//pruebas
        readEvidencias,//evidencias
        readTT,//Tecnical test
        readEstatus,//tiempos de estatus
        getUserPuesto,//usuario puesto
} = require('../controllers/read');
const router = Router();

////tabla home
router.get('/tabla',readProduccion);

//Produccion
router.get('/', getAllProducts);
//Calidad
router.get('/all', getAllForms);
//pruebas
router.get('/pruebas', readPruebas);
//evidencias
router.get('/evidencias', readEvidencias);
//TT
router.get('/tt', readTT);
//estatus tiempos
router.get('/estatus', readEstatus);

//usuario
router.get('/user', getUserPuesto);

module.exports = router;
