// Rutas de forms
// host + /api/update
const {check} = require('express-validator') 
const { Router } = require('express');
const { upload } = require('../helpers/filehelper');
const { singleFileUpload, multipleFileUpload, getallSingleFiles } = require('../controllers/uploader');
const router = Router();

router.post('/singleFile', upload.single('file'), singleFileUpload);
router.post('/multipleFile', upload.array("files[]",20), multipleFileUpload);

router.get('/getSingleFile', getallSingleFiles);


module.exports = router;
