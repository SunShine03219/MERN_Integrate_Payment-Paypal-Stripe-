// Rutas de forms
// host + /api/update
const {check} = require('express-validator') 
const { Router } = require('express');
const { UpdateProduccion, UpdateCalidad, UpdateTecnicalTest,
 UpdatePruebas, UpdateEstatus } = require('../controllers/forms');
const router = Router();

//Produccion
router.post("/",UpdateProduccion);
//Calidad
router.post("/calidad",UpdateCalidad);
//pruebas
router.post("/pruebas",UpdatePruebas);
//tt
router.post("/tt",UpdateTecnicalTest);
//evidencias
router.post("/estatus",UpdateEstatus);

module.exports = router;