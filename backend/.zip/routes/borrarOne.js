// host + /api/borrar
const { Router } = require('express');
const { borrarOne } = require('../controllers/forms');
const router = Router();

router.post('/',borrarOne);

module.exports = router;