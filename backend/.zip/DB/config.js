
const mongoose = require("mongoose");

const dbConnection = async()=>{
    try{
        // 'mongodb://localhost:27017/Forms2';
        mongoose.connect("mongodb://mongo:27017/Forms2", {
        });
          
        console.log('MongoDB activa');  
    }catch(error){
        console.log(error);
        throw new Error('error iniciando MongoDB');
    }
}

module.exports ={
    dbConnection
}

