const{Schema,model} = require("mongoose");

const UsuarioSchema = Schema({
    name:{
        type:String,
        require:true
    },
    email:{
        type:String,
        require:true,
        unique: true
    },
    pwd:{
        type:String,
        require:true
    },
    puesto:{
        type:String,
    }

});

module.exports= model('Usuario',UsuarioSchema)