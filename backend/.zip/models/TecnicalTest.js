const{Schema,model} = require("mongoose");

const TecnicalTestSchema = Schema({
    bahia:{
        type:String,
    },
    how_conect:{
        type:String,
    },
    how_disconect:{
        type:String,
    },
    coment_TT:{
        type:String,
    }
});

module.exports= model('TecnicalTest',TecnicalTestSchema)



