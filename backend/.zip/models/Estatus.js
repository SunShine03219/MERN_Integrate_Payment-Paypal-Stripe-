const{Schema,model} = require("mongoose");

const EstadoFinalSchema = Schema({
    entrada:{
        type:String,
    },
    salida:{
        type:String,
    },
    tiempo_total:{
        type:String,
    }
});

module.exports= model('EstadoFinal',EstadoFinalSchema)