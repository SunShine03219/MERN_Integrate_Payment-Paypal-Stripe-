const{Schema,model} = require("mongoose");

const PruebaSchema = Schema({
    te_tt_t1:{
        type:String,
    },
    te_tt_t2:{
        type:String,
    },
    te_tt_t3:{
        type:String,
    },
    gems_cems:{
        type:String,
        require:true
    },
    vpd_seagates:{
        type:String,
    },
    comentarioT:{
        type:String,
    },
    detalles_hold:{
        type:String,
    },
    solucion_hold:{
        type:String,
    },
    evidencias:{
        type:String
    }
});

module.exports= model('Prueba',PruebaSchema)
