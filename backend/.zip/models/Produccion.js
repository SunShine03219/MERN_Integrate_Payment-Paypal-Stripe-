const{Schema,model} = require("mongoose");

const ProduccionSchema = Schema({
    status:{
        type:String,
        require:true
    },
    orden:{
        type:String,
        require:true
    },
    modelo:{
        type:String,
        require:true
    },
    configuracion:{
        type:String,
        require:true
    },
    numero_wu:{
        type:String,
        require:true
    },
    numero_ems:{
        type:String,
        require:true
    },
    cliente:{
        type:String,
        require:true
    },
    pais:{
        type:String,
        require:true
    },
    switch1:{
        type:String,

    },
    switch2:{
        type:String,
    },
    version:{
        type:String,
        require:true
    },
    tipo:{
        type:String,
        require:true
    },
    num_adaptadores:{
        type:String,
    },
    num_adaptadores2:{
        type:String,
    },
    comentConfig:{
        type:String,
    },
    comentarios:{
        type:String,
    },
    asig_ing:{
        type:String,
    },
    ETTC:{
        type:String,
    },

});

module.exports= model('Produccion',ProduccionSchema)